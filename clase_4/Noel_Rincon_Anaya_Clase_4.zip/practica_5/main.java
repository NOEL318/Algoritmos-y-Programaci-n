/* 
Noel Rincón Anaya 181233 ---For
*/
public class main {
    public static void main(String[] args) {
        for (int i = 200; i >= 1; i--) {
            System.out.println(i);
        }
    }
}
