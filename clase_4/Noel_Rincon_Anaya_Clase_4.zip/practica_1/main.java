
/* 
Noel Rincón Anaya 181233 ---Char comparaciones y trato de Strings como arrays
*/
public class main {
    public static void main(String[] args) {
        String alumno1, alumno2, alumno3;
        alumno1 = "Luis";
        alumno2 = "Daniel";
        alumno3 = "Luis";

        System.out.println(alumno1.charAt(0));
        System.out.println("Numero de letras " + alumno1.length());
        System.out.println(alumno1.length() - 1);
        System.out.println(alumno1.equals(alumno2));
        System.out.println(alumno1.equals(alumno3));

    }
}
